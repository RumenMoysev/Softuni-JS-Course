let _id 
let accessToken


export async function home() {
    HideNShow("home-page")
    let email = sessionStorage.getItem("email")    

    if (email == null) {
        document.querySelectorAll(".nav-link")[0].style.display = "none"
        document.querySelectorAll(".nav-link")[1].style.display = "none"
        document.querySelectorAll(".nav-link")[2].style.display = "block"
        document.querySelectorAll(".nav-link")[3].style.display = "block"
        document.querySelector(".btn.btn-warning").style.display = "none"
    } else {
        document.querySelectorAll(".nav-link")[0].textContent = `Welcome, ${email}`
        document.querySelectorAll(".nav-link")[0].style.display = "block"
        document.querySelectorAll(".nav-link")[1].style.display = "block"
        document.querySelectorAll(".nav-link")[2].style.display = "none"
        document.querySelectorAll(".nav-link")[3].style.display = "none"
        document.querySelector(".btn.btn-warning").style.display = "inline"
    }
    

    let section = document.getElementById("movies-list")
    section.innerHTML = ""
    await fetch('http://localhost:3030/data/movies')
        .then(resp => resp.json())
        .then(data => {
            Object.values(data).forEach(movie => {
                let li = document.createElement('li')
                li.className = "card mb-4"
                li.innerHTML = `
            <img class="card-img-top" src="${movie.img}"
                alt="Card image cap" width="400">
            <div class="card-body">
                <h4 class="card-title">${movie.title}</h4>
                <a href="#"
                    <button data-id="${movie._id}" type="button" class="btn btn-info">Details</button>
                </a>
            </div>
            <div class="card-footer">
            </div>
            `
                section.appendChild(li)
            })
        })
        let btns = document.getElementsByClassName("btn btn-info")


        for(let i = 0; i < btns.length;i++){
            btns[i].addEventListener("click", Details)
        }
}
export function login() {
    HideNShow("form-login")
    let form = document.getElementById("login-form")
    let btn = form.children[2]
    btn.addEventListener("click", Log)
    let email = sessionStorage.getItem("email")

    if (email == null) {
        document.querySelectorAll(".nav-link")[0].style.display = "none"
        document.querySelectorAll(".nav-link")[1].style.display = "none"
        document.querySelectorAll(".nav-link")[2].style.display = "block"
        document.querySelectorAll(".nav-link")[3].style.display = "block"
    } else {
        document.querySelectorAll(".nav-link")[0].textContent = `Welcome ${email}`
        document.querySelectorAll(".nav-link")[0].style.display = "block"
        document.querySelectorAll(".nav-link")[1].style.display = "block"
        document.querySelectorAll(".nav-link")[2].style.display = "none"
        document.querySelectorAll(".nav-link")[3].style.display = "none"
    }

    async function Log(e) {
        e.preventDefault()
        let formInfo = new FormData(form)
        let email = formInfo.get("email")
        let password = formInfo.get("password")
        let data = JSON.stringify({ email, password })
        try {
            let resp = await fetch(`http://localhost:3030/users/login`, {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: data
            })

            if (!resp.ok) {
                let err = await resp.json()
                throw new Error(err.message)
            }

            let laina = await resp.json()


            accessToken = laina.accessToken
            _id = laina._id

            sessionStorage.setItem("email", laina.email)
            sessionStorage.setItem("accessToken", laina.accessToken)
            sessionStorage.setItem("id", laina._id)
            form.reset()
            home()
        } catch (err) {
            alert(err)
        }
    }
}

export async function logout() {
    let resp = await fetch(`http://localhost:3030/users/login`, {
                method: "DELETE",
                headers: { 'X-Authorization': sessionStorage.getItem("accessToken") },
            })
    sessionStorage.removeItem("email")
    sessionStorage.removeItem("accessToken", accessToken)
    sessionStorage.removeItem("id", _id)
    login()
}

export function register() {
    HideNShow("form-sign-up")
    let form = document.getElementById("register-form")
    let btn = form.children[3]
    btn.addEventListener("click", Reg)

    async function Reg(e) {
        e.preventDefault()
        let formInfo = new FormData(form)
        let email = formInfo.get("email")
        let password = formInfo.get("password")
        let repass = formInfo.get("repeatPassword")
        let emailpat = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/
        let pass = emailpat.test(email)
        let passpass
        if (password.length < 6) {
            passpass = false
        } else {
            passpass = true
        }

        if ((email && pass) && (password && passpass) && (repass && password === repass)) {
            try {
                let data = JSON.stringify({ email, password })
                let resp = await fetch(`http://localhost:3030/users/register`, {
                    method: "POST",
                    headers: { 'Content-Type': 'application/json' },
                    body: data
                })

                if (!resp.ok) {
                    let err = await resp.json()
                    throw new Error(err.message)
                }

                let laina = await resp.json()

                accessToken = laina.accessToken
                _id = laina._id

                sessionStorage.setItem("email", laina.email)
                sessionStorage.setItem("accessToken", laina.accessToken)
                sessionStorage.setItem("id",laina._id)
                form.reset()
                home()
            } catch (err) {
                alert(err)
            }
        }
    }

}

let addbtn = document.querySelector(".btn.btn-warning")
addbtn.addEventListener("click", Add)

export async function Add() {
    HideNShow("add-movie")
    let subbtn = document.querySelector(".btn.btn-primary")
    subbtn.addEventListener("click", Sub)

    async function Sub(e){
        e.preventDefault()
        let form = document.getElementById("add-movie-form")
        let FormInfo = new FormData(form)
        let title = FormInfo.get("title")
        let description = FormInfo.get("description")
        let img = FormInfo.get("img")
        if (title && description && img) {
            try{
                let data = JSON.stringify({title, description, img})
                console.log(accessToken)
                let resp = await fetch ('http://localhost:3030/data/movies', {
                    method: "POST",
                    headers: { 
                        'Content-Type': 'application/json',
                        'X-Authorization': sessionStorage.getItem("accessToken")
                     },
                    body: data
                })

                if (!resp.ok) {
                    let err = await resp.json()
                    throw new Error(err.message)
                }
                home()
            }catch(err){
                alert(err)
            }

        }
    }

}

let movieid

let movietit
let movieimg
let moviedescription

async function Details(e){
    e.preventDefault()
    HideNShow("movie-example")
    movieid = e.target.dataset.id
    let div
    let likenum = await checkLiked()
    document.getElementById("movie-example").innerHTML = ""
    await fetch(`http://localhost:3030/data/movies/${movieid}`)
    .then(resp => resp.json())
    .then(data => {
        movietit = data.title
        movieimg = data.img
        moviedescription = data.description
            document.getElementById("movie-example").innerHTML = `
            <div class="container">
            <div class="row bg-light text-dark">
              <h1>Movie title: ${data.title}</h1>
  
              <div class="col-md-8">
                <img
                  class="img-thumbnail"
                  src="${data.img}"
                  alt="Movie"
                />
              </div>
              <div class="col-md-4 text-center">
                <h3 class="my-3">Movie Description</h3>
                <p>
                  ${data.description}
                </p>
                <a class="btn btn-danger" href="#">Delete</a>
                <a class="btn btn-warning" href="#">Edit</a>
                <a class="btn btn-primary" href="#">Like</a>
                <span class="enrolled-span">Liked ${likenum}</span>
              </div>
            </div>
          </div>
            `
            div = document.querySelector(".col-md-4.text-center")

            let id = sessionStorage.getItem("id")
            if(!sessionStorage.getItem("id")){
                div.children[2].style.display = "none"
                div.children[3].style.display = "none"
                div.children[4].style.display = "none"
            }else if(id != data._ownerId){
                div.children[2].style.display = "none"
                div.children[3].style.display = "none"
            }else{
                div.children[4].style.display = "none"
            }
    })
    div.children[2].addEventListener("click", Del)
    div.children[3].addEventListener("click", Edit)
    div.children[4].addEventListener("click", Like)
}

async function Del(){
    await fetch(`http://localhost:3030/data/movies/${movieid}`, {
        method: "DELETE", 
        headers: {
            'X-Authorization': sessionStorage.getItem("accessToken")
        },
    })
    home()
}

async function Edit(){
    HideNShow("edit-movie")
    let form = document.getElementsByClassName("text-center border border-light p-5")[1]
    console.log(form)
    form.children[1].children[1].value = movietit
    form.children[2].children[1].value = moviedescription
    form.children[3].children[1].value = movieimg
    let btn = form.children[4]
    console.log(btn)
    btn.addEventListener('click', edit)
}

async function edit(e){
    e.preventDefault()
    let form = document.getElementsByClassName("text-center border border-light p-5")[1]
    let formInfo = new FormData(form)
    let title = formInfo.get("title")
    let description = formInfo.get("description")
    let img = formInfo.get("img")
    if(title && description && img){
        let data = JSON.stringify({title, description, img})
        try{
            let resp = await fetch(`http://localhost:3030/data/movies/${movieid} `, {
                method: "PUT",
                headers: {
                    'Content-Type': 'application/json',
                    'X-Authorization': sessionStorage.getItem("accessToken")
                },
                body: data
            })

            if (!resp.ok) {
                let err = await resp.json()
                throw new Error(err.message)
            }

            HideNShow("movie-example")
        }catch(err){
            alert(err)
        }

    }

}

async function checkLiked(){
    let resp = await fetch(`http://localhost:3030/data/likes?where=movieId%3D%22${movieid}%22&distinct=_ownerId&count`)
    let data = await(resp.json())
    return data
}

let i = 0

async function Like(){
    try{
        let movieId = movieid
        let data = JSON.stringify({movieId})
        let resp = await fetch(`http://localhost:3030/data/likes`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': sessionStorage.getItem("accessToken")
            },
            body: data
        })

        if (!resp.ok) {
            let err = await resp.json()
            throw new Error(err.message)
        }

        let btn = document.getElementsByClassName("btn btn-primary")[1]
        btn.remove()
        let span = document.getElementsByClassName("enrolled-span")[0]
        span.textContent = `Liked ${await checkLiked()}`
    }catch(err){
        alert(err)
    }
}

export function HideNShow(id) {
    document.querySelectorAll(".view-section").forEach((section) => (section.style.display = "none"))
    document.getElementById(id).style.display = "block"
}

