import { home } from "./help.js"
import { login } from "./help.js"
import { register } from "./help.js"
import { logout } from "./help.js"

const routes = {
    "/": home,
    "/login": login,
    "/register": register,
    "/logout": logout
}


document.querySelector("nav").addEventListener("click", OnNav)

function OnNav(e) {
    if (e.target.tagName === "A" && e.target.href) {
        e.preventDefault()
        const url = new URL(e.target.href)
        const view = routes[url.pathname]
        view()
    }
}

home()






