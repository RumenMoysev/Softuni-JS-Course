export function createElement1(type, text, parent, className) {
    let element = document.createElement(type)
    element.textContent = text

    if(text !== undefined) {
        element.textContent = text
    }
  
    if(className !== undefined) {
      element.className = (className)
    }
    parent.appendChild(element)
  
    return element
}